import Express from "express";
import Asana from "asana";
import CookieParser from "cookie-parser";
import BodyParser from 'body-parser';
import PriorityQueue from 'p-queue'
import AsanaHandler from './AsanaHandler.js';
import Database from "@replit/database";

const db = new Database();
const NumberOfRequests = 120; //https://developers.asana.com/docs/rate-limits
const PQueue = new PriorityQueue({ concurrency: 15, interval: 60000, intervalCap: NumberOfRequests }); //free trail rate limit: 150 calls per minute
const App = Express();
const Port = 3000;
const AHandler = new AsanaHandler(60000); //should be greater or equal 60000

let user = null;
const asanaPat = process.env['ASANA_PAT']

//https://stackoverflow.com/questions/19917401/error-request-entity-too-large
App.use(BodyParser.urlencoded({ extended: true, limit: '100mb' }));
App.use(BodyParser.json({ limit: '100mb' }));
App.use(CookieParser());

//add the url of your current replit
const replitUrl = "https://PROJECT.NAME.repl.co"

let asanaClient = Asana.Client.create({
  clientId: process.env.CLIENT_ID,
  clientSecret: process.env.CLIENT_SECRET,
  redirectUri: replitUrl + "/oauthCallback",
  scope: "user profile email default openid",
  defaultHeaders: { 'Asana-Enable': 'string_ids, new_goal_memberships' }
});

//-----------------------------------ASANA GET ENDPOINTS----------------------------------------------

//get a merged json object from feedback and bug project with ticket fetcher
App.get('/GetAllPlayer', async function(req, res) {
  res.send(AHandler.playerTickets);
});

//get a merged json object from feedback and bug project with ticket fetcher
App.get('/GetAllDev', async function(req, res) {
  res.send(AHandler.devTickets);
});

//Get Report Tags
App.get('/GetReportTags', async function(req, res) {
  try {
    res.header("Content-Type", 'application/json');
    res.send(JSON.stringify(AHandler.reportTags));
  } catch (e) {
    console.log(e);
    res.sendStatus(500);
  }
});

//----------------------------------ASANA POST ENDPOINTS----------------------------------------------

//post JSON formatted body to asana an hopefully attach image someday
App.post('/PostNewTaskData/:userId', async function(req, res) {
  try {
    let token = await getTokenFromUser(req.params.userId);
    if (token == null) {
      token = asanaPat;
    }
    PQueue.add(async () => await AHandler.postNewTask(req.body, token));
    res.sendStatus(200)
  } catch {
    res.sendStatus(500);
  }
});

//-----------------------------BASIC AUTHENTICATION ENDPOINTS-----------------------------------------

App.get("/getUserWithUniqueId/:uniqueId", async (req, res) => {
  let uniqueId = req.params.uniqueId;
  let keys = await db.list();
  for (let key of keys) {
    let databaseEntry = await db.get(key);
    if (databaseEntry.uniqueId == uniqueId) {
      res.send({ gid: key, name: databaseEntry.name, email: databaseEntry.email, picture: databaseEntry.picture });
      return;
    }
  }
  res.end("No matching user authorized. Please authenticate with AuthenticateUser endpoint.")
})

//-----------------------------------USER LOGIN ENDPOINTS---------------------------------------------

App.get("/Login/:uniqueId", async (req, res) => {
  let uniqueId = req.params.uniqueId;
  let token = req.cookies.token;
  let refreshtoken = req.cookies.refreshtoken;

  if (token != null && refreshtoken != null) {
    fetch("https://app.asana.com/api/1.0/openid_connect/userinfo", {
      headers: { Authorization: `Bearer ${token}` }
    }).then(async response => {
      user = await response.json();

      let databaseEntry = await db.get(user.sub);
      if (databaseEntry == null) {
        let newClient = { uniqueId: uniqueId, token: token, refreshtoken: refreshtoken, name: user.name, email: user.email, picture: user.picture };
        db.set(user.sub, newClient);
      } else {
        databaseEntry.uniqueId = uniqueId;
        db.set(user.sub, databaseEntry);
      }
      res.end(
        `Hello ${user.name}, you are now logged in with your asana account! You can now switch back to Endzone.`,
      );
    });
  } else {
    res.cookie('uniqueId', uniqueId, { maxAge: 60 * 60 * 1000 });
    res.redirect(asanaClient.app.asanaAuthorizeUrl());
  }
})

App.get("/oauthCallback", (req, res) => {
  try {
    let code = req.query.code;
    if (code != "") {
      asanaClient.app.accessTokenFromCode(code).then(function(credentials) {
        res.cookie("token", credentials.access_token, { maxAge: 60 * 60 * 1000 });
        res.cookie("refreshtoken", credentials.refresh_token, { maxAge: 60 * 60 * 1000 });
        res.redirect(replitUrl + "/Login/" + req.cookies.uniqueId);
        code = "";
      });
    } else {
      res.end("Error getting authorization: " + req.param("error"));
    }
  } catch (e) {
    console.log(e);
  }
})

App.get("/Logout/:uniqueId", async (req, res) => {
  let uniqueId = req.params.uniqueId;
  let keys = await db.list();
  for (let key of keys) {
    let databaseEntry = await db.get(key);
    if (databaseEntry.uniqueId == uniqueId) {
      db.delete(key);
      res.end("Log out user: " + databaseEntry.name);
      return;
    }
  }
  res.end("No User found");
})

async function getTokenFromUser(userId) {
  let token = "";
  let databaseEntry = await db.get(userId);
  if (databaseEntry != null) {
    await asanaClient.app.accessTokenFromRefreshToken(databaseEntry.refreshtoken).then(function(credentials) {
      databaseEntry.token = credentials.access_token;
      db.set(userId, databaseEntry);
    });
    token = databaseEntry.token;
  }

  if (token == "" || userId == null || userId == "") {
    token = null;
  }
  return token;
}

//-------------------------------------------SETUP----------------------------------------------------

App.listen(Port, () => {
  console.log(`Server started on port ${Port}`);
  AHandler.loadReportTags()
});
