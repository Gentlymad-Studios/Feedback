import Asana from "asana";
// define what content types we'll allow
const allowedContentTypes = ['image/jpeg', 'text/plain', 'application/zip'];
const asanaPat = process.env['ASANA_PAT']
const playerProjects = [process.env['ASANA_PLAYERBUG_ID'], process.env['ASANA_PLAYERFEEDBACK_ID']]
const devProjects = [process.env['ASANA_DEVBUG_ID'], process.env['ASANA_DEVFEEDBACK_ID']]

let asanaClient = null;
let intervallTime = null;

export default class AsanaHandler {
  constructor(i) {
    intervallTime = i;
    asanaClient = Asana.Client.create().useAccessToken(asanaPat);
    asanaClient.dispatcher.logAsanaChangeWarnings = false;

    //Init Ticket load once
    this.fetchAllPlayerTicketsInIntervall();
    this.fetchAllDevTicketsInIntervall();

    //Set Interval Functions
    setInterval(() => { this.fetchAllPlayerTicketsInIntervall() }, intervallTime);
    setInterval(() => { this.fetchAllDevTicketsInIntervall() }, intervallTime);
  }

  //---------------------------------TASK FETCH-------------------------------------------

  //get a merged json object from player projects, fetch in intervall
  async fetchAllPlayerTicketsInIntervall() {
    let tickets = [];
    await this.fetchTasks(playerProjects, tickets);
    this.playerTickets = tickets
  }

  //get a merged json object from dev projects, fetch in intervall
  async fetchAllDevTicketsInIntervall() {
    let tickets = [];
    await this.fetchTasks(devProjects, tickets);
    this.devTickets = tickets
  }

  // fetch tasks from the given projects
  async fetchTasks(projects, collection) {
    let project = null;

    for (let index in projects) {
      project = projects[index];
      await asanaClient.tasks.findByProject(project, { opt_fields: 'gid,custom_fields,created_at,name,notes', opt_pretty: true, limit: "100" }).then(async res => {
        res.data.forEach(task => {
          task['project_id'] = project;
          collection.push(task);
        });
        if (res._response.next_page != null) {
          await this.fetchTasksWithPagination(project, collection, res._response.next_page.offset);
        }
      });
    }

  }

  // fetch tasks with pagination from the given project
  async fetchTasksWithPagination(projectId, collection, offset) {
    while (offset != null) {
      await asanaClient.tasks.findByProject(projectId, { opt_fields: 'gid,custom_fields,created_at,name,notes', opt_pretty: true, limit: "100", offset: offset }).then(response => {
        response.data.forEach(task => {
          task['project_id'] = projectId;
          collection.push(task);
        });
        if (response._response.next_page != null) {
          offset = response._response.next_page.offset
        } else {
          offset = null;
        }
      });
    }
  }

  //---------------------------------UTILS-------------------------------------------

  // Loads all ReportsTags from Asana and store them into "reportTags"
  async loadReportTags() {
    let custom_field_gid = process.env['ASANA_REPORTTAGS_ID'];
    let opts = {
      'opt_fields': "enum_options,enum_options.name,enum_options.enabled"
    };
    await asanaClient.customFields.getCustomField(custom_field_gid, opts).then((field) => {
      let new_enum_options = [];
      for (let entry in field.enum_options) {
        if (field.enum_options[entry].enabled) {
          new_enum_options.push(field.enum_options[entry])
        }
      }
      this.reportTags = field
      this.reportTags.enum_options = new_enum_options
      console.log("\nReportTags loaded:")
      console.log(this.reportTags)
    }, (error) => {
      console.error(error.response.body);
    });
  }

  //---------------------------------TASK POST-------------------------------------------

  //Function to post a new ticket
  async postNewTask(data, token) {
    //store attachment array in local variable
    let attachments = data.attachments;

    //delete attachments to create task
    //(array is not a valid type for task creation)
    var key = "attachments";
    delete data[key];
    let createTaskData = { data: data };

    //toss array if it has only one value
    for (let field in data.custom_fields) {
      if (data.custom_fields[field].length == 1) {
        data.custom_fields[field] = data.custom_fields[field][0]
      }
    }

    const options = {
      method: 'POST',
      headers: {
        accept: 'application/json',
        authorization: `Bearer ${token}`
      },
      body: JSON.stringify(createTaskData)
    }

    let createdTaskId = "";
    let taskResponse = "";

    // Create Task
    await fetch('https://app.asana.com/api/1.0/tasks/', options)
      .then(async response => response.json())
      .then(response => {
        taskResponse = response;
        createdTaskId = response.data.gid;
      })
      .catch(err => {
        console.log(taskResponse);
        console.error(err);
      });

    console.log("\nNew Task Created: " + data.name)

    let validAttachments = this.getValidAttachments(attachments);
    let imageId = "";
    let attachmentResponse = "";

    for (const a of validAttachments) {
      const formData = await this.buildAttachments(a, createdTaskId);
      options.body = formData;

      await fetch(`https://app.asana.com/api/1.0/attachments`, options)
        .then(res => res.json())
        .then(res => {
          attachmentResponse = res;
          if (a.contentType.startsWith('image')) {
            imageId = res.data.gid
          }
        })
        .catch(err => {
          console.log(attachmentResponse);
          console.error(err);
        });
    }

    //Create update TaskData
    let updatedTaskData = {}
    updatedTaskData.data = { "html_notes": createTaskData.data.html_notes.replace("</body>", "<img data-asana-gid=\"" + imageId + "\"></body>") };

    const updateOptions = {
      method: 'PUT',
      headers: {
        accept: 'application/json',
        authorization: `Bearer ${token}`
      },
      body: JSON.stringify(updatedTaskData)
    };

    // Update Task
    await fetch('https://app.asana.com/api/1.0/tasks/' + createdTaskId, updateOptions)
      .then(async response => response.json())
      //.then(response => console.log(response))
      .catch(err => console.error(err));
  }

  //Build Attachments
  async buildAttachments(attachment, createdTaskId) {
    // get blob based off the raw base64 string
    const base64Response = await fetch(`data:${attachment.contentType};base64,${attachment.content}`);
    const blob = await base64Response.blob();

    // create formData, append blob & add the createdTaskId as the parent field
    const formData = new FormData();
    formData.append('file', blob, attachment.filename);
    formData.append('parent', createdTaskId);

    return formData;
  }

  //Returns a filtered list of valid attachments
  getValidAttachments(attachments) {
    let validAttachments = [];

    for (let i = 0; i < attachments.length; i++) {
      let attachment = attachments[i];
      for (let j = 0; j < allowedContentTypes.length; j++) {
        if (allowedContentTypes[j] === attachments[i].contentType) {
          validAttachments.push(attachment);
          break;
        }
      }
    }
    return validAttachments;
  }
}
